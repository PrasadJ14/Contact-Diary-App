package com.prasad.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.prasad.recyclerviewdemo.data.MyDbHandler;

public class UpdateContact extends AppCompatActivity {

    TextView person_name, person_phone;
    ImageView call, edit;
    EditText new_name, new_number;
    Button save, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_contact);

        person_name = findViewById(R.id.tvName);
        person_phone = findViewById(R.id.tvPhone);
        call = findViewById(R.id.imgCall);
        edit = findViewById(R.id.imgEdit);
        new_name = findViewById(R.id.etName);
        new_number = findViewById(R.id.etPhone);
        save = findViewById(R.id.bsave);
        delete = findViewById(R.id.bdelete);

        new_name.setVisibility(View.INVISIBLE);
        new_number.setVisibility(View.INVISIBLE);
        save.setVisibility(View.INVISIBLE);
        delete.setVisibility(View.INVISIBLE);

        Intent i = getIntent();
        String pname = i.getStringExtra("name");
        String pphone = i.getStringExtra("phone");

        person_name.setText(pname);
        person_phone.setText(pphone);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dexter.withContext(UpdateContact.this)
                        .withPermission(Manifest.permission.CALL_PHONE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+pphone));
                                startActivity(i);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                                Toast.makeText(UpdateContact.this, "Requires Call permission...", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();
                            }
                        }).check();




            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new_name.setVisibility(View.VISIBLE);
                new_number.setVisibility(View.VISIBLE);
                save.setVisibility(View.VISIBLE);
                delete.setVisibility(View.VISIBLE);

                new_name.setText(person_name.getText());
                new_number.setText(person_phone.getText());

            }
        });

        MyDbHandler db = new MyDbHandler(UpdateContact.this);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (new_name.getText().toString().isEmpty() || (new_number.getText().toString().isEmpty())){

                    new_name.setError("Field can't be empty");
                    new_number.setError("Field can't be empty");

                }else {

                    String ogName = person_name.getText().toString();
                    String new_n = new_name.getText().toString();
                    String new_p = new_number.getText().toString();
                    //call update() from main activity
                    db.updateContact(ogName, new_n, new_p);
                    Toast.makeText(UpdateContact.this, "Update successfully...", Toast.LENGTH_SHORT).show();
                    person_name.setText(new_n);
                    person_phone.setText(new_p);
                    Intent i = new Intent(UpdateContact.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String ogName = person_name.getText().toString();
                db.deleteContact(ogName);
                Toast.makeText(UpdateContact.this, "Deleted successfully...", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateContact.this, MainActivity.class);
                startActivity(i);

            }
        });


    }
}