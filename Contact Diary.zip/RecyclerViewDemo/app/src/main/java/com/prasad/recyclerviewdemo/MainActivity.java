package com.prasad.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.prasad.recyclerviewdemo.Adapter.RecyclerAdapter;
import com.prasad.recyclerviewdemo.data.MyDbHandler;
import com.prasad.recyclerviewdemo.model.Contact;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    MyDbHandler db = new MyDbHandler(MainActivity.this);
    FloatingActionButton addToContact;

    private RecyclerView recyclerView;
    private RecyclerAdapter recyclerAdapter;
    private ArrayList<Contact> contactArrayList;
    private ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addToContact = findViewById(R.id.addContact);

        //recyclerView intiallization;

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        contactArrayList = new ArrayList<>();

        List<Contact> contactList = db.getAllContacts();
        for (Contact contact: contactList){

            contactArrayList.add(contact);

        }

        //using recyclerView
        recyclerAdapter = new RecyclerAdapter(MainActivity.this, contactArrayList);
        recyclerView.setAdapter(recyclerAdapter);

        addToContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddNewContact.class);
                startActivity(i);
            }
        });
    }
}