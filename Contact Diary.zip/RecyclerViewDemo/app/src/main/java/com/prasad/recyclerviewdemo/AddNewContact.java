package com.prasad.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.prasad.recyclerviewdemo.data.MyDbHandler;

public class AddNewContact extends AppCompatActivity {

    EditText newN, newP;
    Button addContactButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_contact);

        newN = findViewById(R.id.newName);
        newP = findViewById(R.id.newPhone);
        addContactButton = findViewById(R.id.addContact);

        MyDbHandler db = new MyDbHandler(AddNewContact.this);

        addContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (newN.getText().toString().isEmpty() || (newP.getText().toString().isEmpty())){

                    Toast.makeText(AddNewContact.this, "Feilds can't be empty!", Toast.LENGTH_SHORT).show();
                }else{

                    String new_name = newN.getText().toString();
                    String new_Phone = newP.getText().toString();

                    db.addContact(new_name, new_Phone);

                    Toast.makeText(AddNewContact.this, "Contact added successfully...", Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(AddNewContact.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });

    }
}