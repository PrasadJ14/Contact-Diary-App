package com.prasad.recyclerviewdemo.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


import com.prasad.recyclerviewdemo.model.Contact;
import com.prasad.recyclerviewdemo.params.Params;

import java.util.ArrayList;
import java.util.List;


public class MyDbHandler extends SQLiteOpenHelper {

    public MyDbHandler(Context context) {
        super(context, Params.DB_NAME, null, Params.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String create = "CREATE TABLE " + Params.DB_NAME + "("
                + Params.KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + Params.KEY_NAME + " TEXT, "
                + Params.KEY_PHONE + " TEXT " + ")";

        db.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

    public void addContact(String name, String phone){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Params.KEY_NAME, name);
        values.put(Params.KEY_PHONE, phone);

        db.insert(Params.DB_NAME, null, values);
        Log.d("dbPrasad", "Successfully inserted... ");
        db.close();

    }
    public List<Contact> getAllContacts(){

        List<Contact> contactList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        //generate the query to read fro database

        String select = "SELECT * FROM " + Params.DB_NAME;
        Cursor cursor = db.rawQuery(select, null);

        //loop through now

        if (cursor.moveToFirst()){

            do {
                Contact contact = new Contact();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setPhoneNumber(cursor.getString(2));

                contactList.add(contact);

            }while (cursor.moveToNext());
        }
        return contactList;
    }

    public void updateContact(String ogName, String pName, String pPhone){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Params.KEY_NAME, pName);
        values.put(Params.KEY_PHONE, pPhone);

        //update now

        db.update(Params.DB_NAME, values, Params.KEY_NAME + "=?",
                new String[]{String.valueOf(ogName)});

        db.close();
    }

    public void deleteContact(String ogName){

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Params.DB_NAME, Params.KEY_NAME + "=?",new String[]{ogName});
        db.close();

    }

}
